import pylint

if __name__ == '__main__':
    pylint.run_pylint()
